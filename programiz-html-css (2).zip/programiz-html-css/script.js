// script.js
function showMore() {
    const extraWishes = document.getElementById('extra-wishes');
    extraWishes.style.display = (extraWishes.style.display === 'block' ? 'none' : 'block');
}
